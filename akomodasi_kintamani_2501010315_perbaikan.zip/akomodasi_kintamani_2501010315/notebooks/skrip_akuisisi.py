import json
import time
import hashlib
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import requests

URL = "https://overpass-api.de/api/interpreter"
HEADERS = {"User-Agent": "INSTIKI-BIFP243-Praktikum/1.0"}
QUERY_PATH = Path("docs/query_overpass.txt")
NAMA = "Ni Putu Riska Pramesti Cahya Dewi"
NIM = "2501010315"


def ambil_data(query):
    """Mengambil data dari Overpass. Maksimal dua kali permintaan."""
    for percobaan in range(2):
        try:
            response = requests.post(
                URL,
                data={"data": query},
                headers=HEADERS,
                timeout=120
            )

            if response.status_code in [429, 504] and percobaan == 0:
                print("Server Overpass sedang sibuk. Menunggu 15 detik...")
                time.sleep(15)
                continue

            response.raise_for_status()
            return response.content, response.json()

        except (requests.Timeout, requests.ConnectionError):
            if percobaan == 0:
                print("Koneksi bermasalah. Mencoba sekali lagi setelah 15 detik...")
                time.sleep(15)
            else:
                raise

    raise RuntimeError("Data gagal diambil. Coba lagi nanti.")


def ubah_ke_tabel(elements):
    baris = []

    for item in elements:
        tag = item.get("tags", {})
        titik = item.get("center", item)

        baris.append({
            "osm_type": item.get("type"),
            "osm_id": item.get("id"),
            "nama": tag.get("name"),
            "jenis": tag.get("tourism"),
            "lat": titik.get("lat"),
            "lon": titik.get("lon"),
            "desa": tag.get("addr:village"),
            "bintang": tag.get("stars"),
            "jumlah_kamar": tag.get("rooms"),
            "website": tag.get("website") or tag.get("contact:website"),
            "url_osm": f"https://www.openstreetmap.org/{item.get('type')}/{item.get('id')}"
        })

    kolom = [
        "osm_type", "osm_id", "nama", "jenis", "lat", "lon", "desa",
        "bintang", "jumlah_kamar", "website", "url_osm"
    ]
    return pd.DataFrame(baris, columns=kolom)


def main():
    query = QUERY_PATH.read_text(encoding="utf-8")

    print("Mengambil data dari OpenStreetMap...")
    raw_bytes, data = ambil_data(query)

    Path("data/raw").mkdir(parents=True, exist_ok=True)
    Path("data/interim").mkdir(parents=True, exist_ok=True)
    Path("docs").mkdir(parents=True, exist_ok=True)

    waktu = datetime.now(timezone.utc)
    nama_file = "osm_akomodasi_kintamani_" + waktu.strftime("%Y%m%d_%H%M%S") + ".json"
    raw_path = Path("data/raw") / nama_file

    # Menyimpan isi respons API apa adanya.
    raw_path.write_bytes(raw_bytes)
    hash_file = hashlib.md5(raw_bytes).hexdigest()

    df = ubah_ke_tabel(data.get("elements", []))
    csv_path = Path("data/interim/akomodasi_kintamani.csv")
    df.to_csv(csv_path, index=False, encoding="utf-8-sig")

    # Membuat 10 sampel untuk pemeriksaan manual.
    if len(df) > 0:
        sampel = df.sample(n=min(10, len(df)), random_state=42).copy()
        sampel["cek_nama"] = "Belum diperiksa"
        sampel["cek_jenis"] = "Belum diperiksa"
        sampel["cek_lokasi"] = "Belum diperiksa"
        sampel["sumber_verifikasi"] = ""
        sampel["catatan"] = ""
        sampel.to_csv(
            "data/interim/sampel_verifikasi_10.csv",
            index=False,
            encoding="utf-8-sig"
        )

    provenance = {
        "nama": NAMA,
        "nim": NIM,
        "sumber": "OpenStreetMap melalui Overpass API",
        "endpoint": URL,
        "query_file": str(QUERY_PATH),
        "query": query,
        "waktu_akuisisi_utc": waktu.isoformat(),
        "jumlah_elemen": len(data.get("elements", [])),
        "file_json": str(raw_path),
        "hash_md5": hash_file,
        "lisensi": "Open Database License (ODbL)",
        "atribusi": "© OpenStreetMap contributors"
    }

    Path("docs/provenance.json").write_text(
        json.dumps(provenance, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    print("\nPengambilan data selesai.")
    print("Jumlah data:", len(df))
    print("Data duplikat:", df.duplicated(["osm_type", "osm_id"]).sum())
    print("Nama kosong:", df["nama"].isna().sum())
    print("Koordinat kosong:", df[["lat", "lon"]].isna().any(axis=1).sum())
    print("CSV:", csv_path)
    print("JSON mentah:", raw_path)

    return df


if __name__ == "__main__":
    main()
