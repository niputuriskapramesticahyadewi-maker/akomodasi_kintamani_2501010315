# LAPORAN PRAKTIK AKUISISI DATA AKOMODASI DI KECAMATAN KINTAMANI

**Nama:** Ni Putu Riska Pramesti Cahya Dewi  
**NIM:** 2501010315  
**Mata Kuliah:** BIFP-243 Akuisisi dan Manajemen Data

## 1. Ringkasan Dataset
Akuisisi dilakukan menggunakan OpenStreetMap melalui Overpass API. Jumlah data yang diperoleh: [isi setelah notebook dijalankan]. Jenis akomodasi yang ditemukan: [isi berdasarkan hasil]. Sebaran per desa: [isi berdasarkan hasil].

## 2. Metode dan Peta Sebaran
Wilayah target adalah Kecamatan Kintamani, Kabupaten Bangli. Query akhir disimpan pada `docs/query_overpass.txt`. Respons mentah disimpan dalam format JSON dan kemudian diratakan menjadi CSV.  
**Peta sebaran:** [tempelkan hasil plot koordinat dari notebook].

## 3. Uji Kelengkapan terhadap BPS
Sumber pembanding: [judul publikasi BPS, tahun, tabel/halaman].  
Jumlah akomodasi menurut BPS: [isi angka]. Jumlah data OSM: [isi angka].  
Persentase kelengkapan = jumlah OSM / jumlah BPS × 100% = [hitung]%.

Jelaskan apakah kategori dan tahun data yang dibandingkan sudah sebanding. Jika angka per kecamatan tidak ditemukan, jelaskan keterbatasan tersebut dan jangan mengganti angka dengan perkiraan.

## 4. Verifikasi 10 Sampel
Tuliskan hasil pengecekan manual nama, jenis, dan lokasi dari maksimal 10 sampel. Lampirkan tabel: nomor, nama akomodasi, tautan OSM, sumber pembanding, kesesuaian nama, kesesuaian jenis, kesesuaian lokasi, catatan.

## 5. Masalah Kualitas Data dan Keputusan
Bahas data duplikat, nama kosong, koordinat kosong/di luar wilayah, desa yang tidak terisi, serta kolom yang banyak kosong. Jelaskan keputusan penanganan dan jangan menghapus data tanpa catatan.

## 6. Refleksi (150–200 kata)
Data akomodasi dari OpenStreetMap tidak dapat langsung dianggap lengkap karena pengisiannya bergantung pada kontribusi pengguna atau relawan. Tidak semua hotel, villa, dan penginapan sudah tercatat, dan informasi yang tersedia pada setiap objek juga berbeda-beda. Ada akomodasi yang memiliki nama dan koordinat, tetapi tidak mencantumkan jumlah kamar, bintang, desa, atau website. Selain itu, beberapa villa dapat menggunakan kategori tag yang berbeda, seperti guest house, chalet, atau apartment. Karena itu, hasil akuisisi lebih tepat dipahami sebagai data yang berhasil ditemukan pada OpenStreetMap saat tanggal pengambilan, bukan jumlah seluruh akomodasi yang benar-benar ada di Kintamani. Untuk meningkatkan kelengkapan, data perlu dibandingkan dengan publikasi resmi BPS dan diverifikasi secara manual melalui situs resmi akomodasi. Penelitian lanjutan juga dapat meminta data dari instansi pariwisata atau portal Satu Data Bali. Setiap sumber harus dicatat asal-usul, tanggal akses, lisensi, dan batas penggunaannya agar data dapat diperiksa kembali dan digunakan secara bertanggung jawab.
