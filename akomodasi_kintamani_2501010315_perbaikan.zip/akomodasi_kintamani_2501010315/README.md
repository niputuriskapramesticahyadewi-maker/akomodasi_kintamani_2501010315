# Akuisisi Data Akomodasi Kecamatan Kintamani

**Nama:** Ni Putu Riska Pramesti Cahya Dewi  
**NIM:** 2501010315  
**Mata kuliah:** BIFP-243 Akuisisi dan Manajemen Data

## Tujuan
Mengambil data akomodasi di Kecamatan Kintamani dari OpenStreetMap melalui Overpass API, menyimpan respons mentah, mengubahnya menjadi CSV, lalu memeriksa kualitas dan keterbatasan data.

## Sumber data
- OpenStreetMap melalui Overpass API: https://overpass-api.de/api/interpreter
- Pembanding: publikasi resmi BPS Kabupaten Bangli, jika tersedia dengan kategori dan wilayah yang sebanding.
- Atribusi: © OpenStreetMap contributors.
- Lisensi: Open Database License (ODbL).

## Sebelum mengambil data
1. Buka `docs/query_batas_kecamatan.txt` di https://overpass-turbo.eu/.
2. Pastikan hasilnya benar-benar batas Kecamatan Kintamani, Kabupaten Bangli, bukan lokasi/desa bernama Kintamani.
3. Jika batas yang muncul tidak sesuai, jangan jalankan akuisisi. Perbaiki query berdasarkan batas yang sudah diverifikasi.
4. Setelah batas benar, periksa query pada `docs/query_overpass.txt`.

## Cara menjalankan di Google Colab
1. Ekstrak ZIP ke `/content/akomodasi_kintamani_extracted/`.
2. Buka `notebooks/akuisisi_akomodasi.ipynb` di Google Colab.
3. Jalankan notebook dari atas ke bawah.
4. Notebook akan mengimpor `notebooks/skrip_akuisisi.py` dan menjalankan akuisisi satu kali.
5. Hasil CSV dan JSON akan disimpan di folder `data/`.
6. Isi hasil perbandingan BPS dan verifikasi sampel secara manual berdasarkan sumber yang benar-benar diperiksa.
7. Lengkapi laporan akhir PDF 3–5 halaman sebelum mengumpulkan.

## Hasil yang dibuat saat akuisisi
- `data/raw/osm_akomodasi_kintamani_<waktu>.json`: respons API mentah.
- `data/interim/akomodasi_kintamani.csv`: data hasil perataan.
- `data/interim/sampel_verifikasi_10.csv`: maksimal 10 sampel yang harus diperiksa manual.
- `docs/provenance.json`: sumber, query, waktu akuisisi, jumlah data, dan hash file.

## Etika dan batasan
- Akuisisi hanya melalui OpenStreetMap dan Overpass API.
- Tidak melakukan scraping Booking.com, Agoda, Traveloka, tiket.com, Airbnb, Tripadvisor, atau halaman Google Maps.
- Tidak mengambil nomor telepon, email, atau akun media sosial pemilik.
- Program membatasi permintaan Overpass maksimal dua kali. Jika gagal, tunggu dan coba lagi nanti.
- Data OSM merupakan data kontribusi komunitas dan tidak otomatis mencakup semua akomodasi.
- Sampel acak yang dibuat program belum berarti sudah diverifikasi. Pemeriksaan nama, jenis, dan lokasi tetap dilakukan manual.
- Angka BPS, hasil verifikasi, dan jumlah data hanya boleh ditulis setelah benar-benar diperiksa; jangan mengarang atau memperkirakan.

## Struktur folder
- `data/raw/`: JSON mentah.
- `data/interim/`: CSV hasil olahan dan sampel verifikasi.
- `notebooks/`: notebook dan script Python.
- `docs/`: query, provenance, kamus data, checklist etika, dan perbandingan BPS.
- `reports/`: template laporan akhir.
